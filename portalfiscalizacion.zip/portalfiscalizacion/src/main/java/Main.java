public class Main {
    public static void main(String[] args) {
        /*
        Employee employee = new Employee();
        employee.setfFirstName("kenni");
        employee.setlLastName("Berlin");

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(employee);
        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
         */
        /*
        SatEstucturaImpuestosDo satEstucturaImpuestosDo = new SatEstucturaImpuestosDo();
        satEstucturaImpuestosDo.setSubCategoria("alcholes");
        satEstucturaImpuestosDo.setSegmento("caja");
        satEstucturaImpuestosDo.setIvaVenta("16");
        satEstucturaImpuestosDo.setIepsVenta("52");
        satEstucturaImpuestosDo.setImpuestoEstatal("SI");
        satEstucturaImpuestosDo.setVatCode("IE1653");

        SatEstucturaImpuestosDo satEstucturaImpuestosDo = new SatEstucturaImpuestosDo();
        satEstucturaImpuestosDo.setSubCategoria("Higiene y Salud");
        satEstucturaImpuestosDo.setSegmento("palet");
        satEstucturaImpuestosDo.setIvaVenta("16");
        satEstucturaImpuestosDo.setImpuestoEstatal("NO");
        satEstucturaImpuestosDo.setVatCode("IVA16");

        SatEstucturaImpuestosDo satEstucturaImpuestosDo = new SatEstucturaImpuestosDo();
        satEstucturaImpuestosDo.setSubCategoria("Lacteos");
        satEstucturaImpuestosDo.setSegmento("Caja");
        satEstucturaImpuestosDo.setImpuestoEstatal("NO");
        satEstucturaImpuestosDo.setVatCode("EXENTO");

        SatEstucturaImpuestosDo satEstucturaImpuestosDo = new SatEstucturaImpuestosDo();
        satEstucturaImpuestosDo.setSubCategoria("Confiteria");
        satEstucturaImpuestosDo.setSegmento("Bolsa");
        satEstucturaImpuestosDo.setIvaVenta("8");
        satEstucturaImpuestosDo.setImpuestoEstatal("NO");
        satEstucturaImpuestosDo.setVatCode("IE0008");

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(satEstucturaImpuestosDo);
        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
*/
    }
}
