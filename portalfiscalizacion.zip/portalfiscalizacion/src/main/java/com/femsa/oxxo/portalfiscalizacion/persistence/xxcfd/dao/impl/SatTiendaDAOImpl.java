package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.impl;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatTiendaDo;
import com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatTiendaDAO;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.util.List;

@Stateless
public class SatTiendaDAOImpl extends AbstractBaseDAO<SatCatTiendaDo> implements ISatTiendaDAO {
/*
* Query nombrado para los registros
* */
    private static final String QUERY_ENCONTRAR_TIENDAS = "SatTiendasDo.findAll";
    /*
     * El {@Linkplain EntityManager} de la persistencia
     * */
    @PersistenceContext(name="xxcfd")
    private EntityManager em;

    /*
    * Constructor por default en la cual se localiza la entidad de grupos
    * */
    public SatTiendaDAOImpl (){
        super(SatCatTiendaDo.class);
    }

    /*
    * constructor en la cual acepta la entidad a manejar
    *
    * @param entityClass
    *       -La entidad a manejar por la prsistencia
    * */
    public SatTiendaDAOImpl(Class<SatCatTiendaDo> entityClass){
        super(entityClass);
    }
    @SuppressWarnings("unchecked")
    @Override
    public List<SatCatTiendaDo> obtenerTiendas() {
        Query queryTienda = getEntityManager().createNamedQuery(
                QUERY_ENCONTRAR_TIENDAS);
        return  queryTienda.getResultList();
    }
    /*
    * (non-Javadoc)
    * @see
    * com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO
    * */
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
