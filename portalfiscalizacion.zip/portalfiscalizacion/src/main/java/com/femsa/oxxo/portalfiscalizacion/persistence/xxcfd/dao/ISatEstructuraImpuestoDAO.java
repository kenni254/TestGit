package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao;

import com.femsa.oxxo.portalfiscalizacion.model.exception.PortalFiscalizacionException;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.to.FiltroSatEstructuraImpuesto;
import jakarta.ejb.Local;

import java.util.List;

/*
 * Integrador para obtener la estructura de impuestos
 * */
@Local
public interface ISatEstructuraImpuestoDAO {
    /*
     * Se comunica con el servicio para obtener los registros de las estructuras
     * de impuestos
     *
     * */
    List<Object[]> obtenerEstructurasImpuestos(FiltroSatEstructuraImpuesto filtro) throws PortalFiscalizacionException;

}
