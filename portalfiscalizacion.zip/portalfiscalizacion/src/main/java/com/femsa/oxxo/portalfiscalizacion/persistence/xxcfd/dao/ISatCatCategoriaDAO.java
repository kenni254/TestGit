package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatCategoriaDo;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface ISatCatCategoriaDAO {
    /**
     * Obtiene los datos de las categorias para el filtro
     * @autor Kenni Juarez (kenni.juarez@hexaware.com.mx)
     */

    List<SatCatCategoriaDo> obtenerCategorias();

}
