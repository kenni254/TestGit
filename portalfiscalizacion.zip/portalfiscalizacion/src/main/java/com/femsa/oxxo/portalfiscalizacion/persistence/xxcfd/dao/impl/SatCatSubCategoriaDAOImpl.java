package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.impl;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatSubCategoriaDo;
import com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatCatSubCategoriaDAO;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.util.List;

@Stateless
public class SatCatSubCategoriaDAOImpl extends AbstractBaseDAO<SatCatSubCategoriaDo> implements ISatCatSubCategoriaDAO {
    /**
     * Query de busqueda de registros
     */
    private static final String QUERY_SUB_CATEGORIA = "SatCatSubCatergoriaDo.findAll";

    @PersistenceContext(name = "xxsat")
    private EntityManager em;

    public SatCatSubCategoriaDAOImpl(){
        super(SatCatSubCategoriaDo.class);
    }

    public SatCatSubCategoriaDAOImpl(Class<SatCatSubCategoriaDo> entityClass){
        super(entityClass);
    }
    @SuppressWarnings("unchecked")
    @Override
    public List<SatCatSubCategoriaDo> obtenerSatSubCategoria() {
        Query querySubCatCategoria = getEntityManager().createNamedQuery(
          QUERY_SUB_CATEGORIA);
        return querySubCatCategoria.getResultList();
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
