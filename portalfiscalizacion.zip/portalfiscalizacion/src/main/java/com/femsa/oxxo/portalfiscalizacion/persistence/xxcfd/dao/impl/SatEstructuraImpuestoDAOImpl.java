package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.impl;

import com.femsa.oxxo.portalfiscalizacion.model.exception.PortalFiscalizacionException;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatEstructuraImpuestoDo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.to.FiltroSatEstructuraImpuesto;
import com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatEstructuraImpuestoDAO;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.util.ArrayList;
import java.util.List;

@Stateless
public class SatEstructuraImpuestoDAOImpl extends AbstractBaseDAO<SatEstructuraImpuestoDo> implements ISatEstructuraImpuestoDAO {

    private static final int ESTADO_PARAM = 1;

    private static final int CRTIENDA_PARAM = 2;

    private static final int CRREGION_PARAM = 3;

    private static final String QUERY_NOMBRADO_ORDENADOS = "satEstructuraImpuesto.findAll";
    @PersistenceContext(name = "default")
    private EntityManager em;

    public SatEstructuraImpuestoDAOImpl() {
        super(SatEstructuraImpuestoDo.class);
    }

    public SatEstructuraImpuestoDAOImpl(Class<SatEstructuraImpuestoDo> entityClass){
        super (entityClass);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Object[]> obtenerEstructurasImpuestos(FiltroSatEstructuraImpuesto filtro) throws PortalFiscalizacionException {
        List<Object[]> resultados = new ArrayList<Object[]>();
        try {
            Query queryOrdenado = getEntityManager().createNamedQuery(QUERY_NOMBRADO_ORDENADOS);
            queryOrdenado.setParameter(ESTADO_PARAM, filtro != null ? filtro.getEstado() : null);
            queryOrdenado.setParameter(CRTIENDA_PARAM, filtro != null ? filtro.getCrTienda() : null);
            queryOrdenado.setParameter(CRREGION_PARAM, filtro != null ? filtro.getCrRegion() : null);
            resultados = queryOrdenado.getResultList();
        } catch (Exception e){
            System.out.println("exception percistence "+ e);
        }
        return resultados;
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }


}
