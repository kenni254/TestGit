package com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name="XXSAT_CAT_TIENDA",  schema="XXSAT")
@NamedQueries({
        @NamedQuery(name="SatTiendasDo.findAll",query = "SELECT t FROM SatCatTiendaDo t")
})
public class SatCatTiendaDo implements Serializable {

    @Id
    @Column(name = "ID")
    private long id;
    @Column(name="CR_TIENDA")
    private String crTienda;

    @Column(name="NOMBRE_TIENDA")
    private String nombreTienda;

    @Column(name="ESTADO")
    private String estado;

    @Column(name="VAT_REGION")
    private Long vatRegion;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCrTienda() {
        return crTienda;
    }

    public void setCrTienda(String crTienda) {
        this.crTienda = crTienda;
    }

    public String getNombreTienda() {
        return nombreTienda;
    }

    public void setNombreTienda(String nombreTienda) {
        this.nombreTienda = nombreTienda;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Long getVatRegion() {
        return vatRegion;
    }

    public void setVatRegion(Long vatRegion) {
        this.vatRegion = vatRegion;
    }
}
