package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatSubCategoriaDo;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface ISatCatSubCategoriaDAO {
    List<SatCatSubCategoriaDo> obtenerSatSubCategoria();
}
