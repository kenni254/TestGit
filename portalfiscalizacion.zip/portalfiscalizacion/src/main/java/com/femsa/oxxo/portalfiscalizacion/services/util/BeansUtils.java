package com.femsa.oxxo.portalfiscalizacion.services.util;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatCategoriaDo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatRegionDo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatSubCategoriaDo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatTiendaDo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.to.CatalogoTo;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.vo.SatEstructuraImpuestoVO;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BeansUtils {

    public static Long castBigDecimalObjToLong(Object bd){
        BigDecimal bigDecimal = (BigDecimal) bd;
        Long resultCast = null;
        if (bigDecimal != null){
            resultCast = bigDecimal.longValue();
        }
        return  resultCast;
    }

    public static String validateStringFromBigDecimal(Object bd){
        String cast = null;
        if(bd != null){
            cast = bd.toString();
        }
        return cast;
    }
    /*
    * Obtiene una lista de Region una lista de catalogos para
    * mostrar en la pantalla
    * Se auxilia del mapeador {@link #obtenerCatRegion(SatCatRegionDo)}
    *
    * @param regiones
    * Los regiones a mostrar en el catalogo
    * @return La lista de los regiones en formato de catalogo
    * @see #obtenerCatRegion(SatCatRegionDo)
    * */
    public static List<CatalogoTo> obtenerCatalogosRegion(List<SatCatRegionDo> regiones){
        List<CatalogoTo> catalogoRegion = new ArrayList<CatalogoTo>();
        if(!regiones.isEmpty()){
            for(SatCatRegionDo region : regiones){
                catalogoRegion.add(obtenerCatalogoRegion(region));
            }
        }
        return catalogoRegion;
    }

    public static CatalogoTo obtenerCatalogoRegion(SatCatRegionDo region){
        CatalogoTo catalogo = null;
        if(region != null){
            catalogo = new CatalogoTo();
            catalogo.setId(region.getId());
            catalogo.setDescripcion(region.getRegionName());
        }
        return catalogo;
    }

    /**
    * Obtiene de una lista de categorias los valores para obtener un
    * objecto {@linkplain CatalogoTo}
    * si categorias se encuentrq vacio, regresa una lista
    * vacia
    * Se auxilia de
    * */
    public static List<CatalogoTo> obtenerCatalogosTienda (List<SatCatTiendaDo> tiendas){
        List<CatalogoTo> catalogoTienda = new ArrayList<CatalogoTo>();
        if(!tiendas.isEmpty()){
            for(SatCatTiendaDo tienda :  tiendas){
                catalogoTienda.add(obtenerCatalogoTienda(tienda));
            }
           }
        return catalogoTienda;
    }

    /**
    * Obtiene el objecto {@linkplain CatalogoTo} de acuerdo a tienda
    * Si categoria es null, se regresa un valor nulo
    * @param tienda
    *       - la tienda a obtener en formato de catalogo
    * @return Un objeto {@linkplain CatalogoTo} con los datos de
    *   tienda
    * */
    public static CatalogoTo obtenerCatalogoTienda(SatCatTiendaDo tienda){
        CatalogoTo catalogo = null;
        if(tienda != null){
            catalogo = new CatalogoTo();
            catalogo.setId(tienda.getId());
            catalogo.setDescripcion(tienda.getCrTienda());
        }
        return catalogo;
    }

    /**
     * Obtiene de una lista de categorias los valores para obtener un
     * objecto {@linkplain CatalogoTo}
     * si categorias se encuentrq vacio, regresa una lista
     * vacia
     * Se auxilia de {@link #obtenerCatalogosCategoria(SatCatCategoriaDo)}
     * */
    public static List<CatalogoTo> obtenerCatalogosCategoria (List<SatCatCategoriaDo> categorias){
        List<CatalogoTo> catalogosCategoria = new ArrayList<CatalogoTo>();
        if(!categorias.isEmpty()){
            for(SatCatCategoriaDo categoria :  categorias){
                catalogosCategoria.add(obtenerCatalogoCategoria(categoria));
            }
        }
        return catalogosCategoria;
    }

    /**
     * Obtiene el objecto {@linkplain CatalogoTo} de acuerdo a tienda
     * Si categoria es null, se regresa un valor nulo
     * @param categoria
     *       - la tienda a obtener en formato de catalogo
     * @return Un objeto {@linkplain CatalogoTo} con los datos de
     *   tienda
     * */
    public static CatalogoTo obtenerCatalogoCategoria(SatCatCategoriaDo categoria){
        CatalogoTo catalogo = null;
        if(categoria != null){
            catalogo = new CatalogoTo();
            catalogo.setId(categoria.getId());
            catalogo.setDescripcion(categoria.getCategoria());
        }
        return catalogo;
    }
/****************************************/
    /**
     * Obtiene de una lista de categorias los valores para obtener un
     * objecto {@linkplain CatalogoTo}
     * si categorias se encuentrq vacio, regresa una lista
     * vacia
     * Se auxilia de {@link #obtenerCatalogosCategoria(SatCatCategoriaDo)}
     * */
    public static List<CatalogoTo> obtenerCatalogosSubCategoria (List<SatCatSubCategoriaDo> subCategorias){
        List<CatalogoTo> catalogosSubCategoria = new ArrayList<CatalogoTo>();
        if(!subCategorias.isEmpty()){
            for(SatCatSubCategoriaDo subCategoria :  subCategorias){
                catalogosSubCategoria.add(obtenerCatalogoSubCategoria(subCategoria));
            }
        }
        return catalogosSubCategoria;
    }

    /**
     * Obtiene el objecto {@linkplain CatalogoTo} de acuerdo a tienda
     * Si categoria es null, se regresa un valor nulo
     * @param categoria
     *       - la tienda a obtener en formato de catalogo
     * @return Un objeto {@linkplain CatalogoTo} con los datos de
     *   tienda
     * */
    public static CatalogoTo obtenerCatalogoSubCategoria(SatCatSubCategoriaDo subCategoria){
        CatalogoTo catalogo = null;
        if(subCategoria != null){
            catalogo = new CatalogoTo();
            catalogo.setId(subCategoria.getId());
            catalogo.setDescripcion(subCategoria.getSubCategoria());
        }
        return catalogo;
    }
/****************************************/
    public static List<SatEstructuraImpuestoVO> obtenerVoSatEstructuraImpuestos(
            List<Object[]>registros) {
        List<SatEstructuraImpuestoVO> catalogos = new ArrayList<SatEstructuraImpuestoVO>();
        if (!registros.isEmpty()) {
            for (Object[] registro : registros) {
                catalogos.add(obtenerVoSatEstructuraImpuesto(registro));
            }
        }
        return catalogos;
    }
    //kjr pendiente
    public static SatEstructuraImpuestoVO obtenerVoSatEstructuraImpuesto (Object[] registro){
        SatEstructuraImpuestoVO catalogo = null;
        if(registro != null){
            catalogo = new SatEstructuraImpuestoVO();
            catalogo.setId(BeansUtils.castBigDecimalObjToLong(registro[0]));
            catalogo.setSuperGrupo(BeansUtils.validateStringFromBigDecimal(registro[1]));
            catalogo.setCategoria(BeansUtils.validateStringFromBigDecimal(5));
        }

    }


}
