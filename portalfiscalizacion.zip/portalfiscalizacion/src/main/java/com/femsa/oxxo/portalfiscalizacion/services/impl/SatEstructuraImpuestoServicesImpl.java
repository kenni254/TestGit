package com.femsa.oxxo.portalfiscalizacion.services.impl;

import com.femsa.oxxo.portalfiscalizacion.model.exception.PortalFiscalizacionException;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.to.FiltroSatEstructuraImpuesto;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.vo.SatEstructuraImpuestoVO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatEstructuraImpuestoDAO;
import com.femsa.oxxo.portalfiscalizacion.services.ISatEstructuraImpuestoServices;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;

import java.util.ArrayList;
import java.util.List;
@Stateless
public class SatEstructuraImpuestoServicesImpl implements ISatEstructuraImpuestoServices {

    @EJB
    private ISatEstructuraImpuestoDAO satEstructuraImpuestoDAO;

    @Override
    public List<SatEstructuraImpuestoVO> obtenerCatalogoEstructuraImpuestoPorFiltro(FiltroSatEstructuraImpuesto filtro) throws PortalFiscalizacionException {
        List<SatEstructuraImpuestoVO> satEstructuraImpuestos = new ArrayList<SatEstructuraImpuestoVO>();
        List<Object[]> registros = satEstructuraImpuestoDAO.obtenerEstructurasImpuestos(filtro);
        satEstructuraImpuestos = BeanUtil.obtenerVo

        return null;
    }
}
