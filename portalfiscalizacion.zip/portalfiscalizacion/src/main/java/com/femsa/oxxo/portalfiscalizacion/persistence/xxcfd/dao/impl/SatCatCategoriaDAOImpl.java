package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.impl;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatCategoriaDo;
import com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatCatCategoriaDAO;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.util.List;

@Stateless
public class SatCatCategoriaDAOImpl extends AbstractBaseDAO<SatCatCategoriaDo> implements ISatCatCategoriaDAO {
    /**
     * Query de busqueda de registros
     */
    private static final String QUERY_ENCONTRAR_CATEGORIAS="SatCatCategoriaDo.findAll";

    @PersistenceContext(name="xxcfd")
    private EntityManager em;

    public SatCatCategoriaDAOImpl(){
        super(SatCatCategoriaDo.class);
    }

    public SatCatCategoriaDAOImpl(Class<SatCatCategoriaDo> entityClass){
        super(entityClass);
    }

    @Override
    public List<SatCatCategoriaDo> obtenerCategorias() {
        Query queryCategorias = getEntityManager().createNamedQuery(
                QUERY_ENCONTRAR_CATEGORIAS);
        return queryCategorias.getResultList();
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

}
