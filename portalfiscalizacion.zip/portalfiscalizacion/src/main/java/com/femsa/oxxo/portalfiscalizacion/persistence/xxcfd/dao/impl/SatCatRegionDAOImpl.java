package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.impl;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatRegionDo;
import com.femsa.oxxo.portalfiscalizacion.persistence.base.dao.AbstractBaseDAO;
import com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao.ISatCatRegionDAO;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import java.util.List;

@Stateless
public class SatCatRegionDAOImpl extends AbstractBaseDAO<SatCatRegionDo> implements ISatCatRegionDAO {
    private static final String QUERY_ENCONTRAR_REGIONES = "SatCatRegionesDo.findAll";

    @PersistenceContext(name = "xxcfd")
    private EntityManager em;

    public SatCatRegionDAOImpl(){
        super(SatCatRegionDo.class);
    }

    public SatCatRegionDAOImpl(Class<SatCatRegionDo> entityClass){
        super(entityClass);
    }
    @SuppressWarnings("unchecked")
    @Override
    public List<SatCatRegionDo> obtenerCatRegion() {
        Query queryRegion= getEntityManager().createNamedQuery(
                QUERY_ENCONTRAR_REGIONES);
        return queryRegion.getResultList();
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
