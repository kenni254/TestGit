package com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name="XXSAT_CAT_REGIONES", schema = "XXSAT")
@NamedQueries({
                @NamedQuery(name="SatCatRegionesDo.findAll", query="SELECT r FROM SatCatRegionDo r")
})
public class SatCatRegionDo implements Serializable {

    private static final long serialVersionUID = 7441318071757795862L;
    @Id
    @Column(name = "REGION")
    private long id;
    @Column(name="REGION_NAME")
    private String regionName;
    @Column(name="NEGOCIO")
    private String negocio;

    @Column(name="ESTATUS")
    private String estatus;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getNegocio() {
        return negocio;
    }

    public void setNegocio(String negocio) {
        this.negocio = negocio;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }
}
