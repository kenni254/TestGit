package com.femsa.oxxo.portalfiscalizacion.persistence.xxcfd.dao;

import com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities.SatCatRegionDo;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface ISatCatRegionDAO {
    List<SatCatRegionDo> obtenerCatRegion();
}
