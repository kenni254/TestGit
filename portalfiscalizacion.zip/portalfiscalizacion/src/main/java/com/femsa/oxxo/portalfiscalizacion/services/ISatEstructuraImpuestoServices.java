package com.femsa.oxxo.portalfiscalizacion.services;

import com.femsa.oxxo.portalfiscalizacion.model.exception.PortalFiscalizacionException;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.to.FiltroSatEstructuraImpuesto;
import com.femsa.oxxo.portalfiscalizacion.model.xxsat.vo.SatEstructuraImpuestoVO;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface ISatEstructuraImpuestoServices {

    List<SatEstructuraImpuestoVO> obtenerCatalogoEstructuraImpuestoPorFiltro (
            FiltroSatEstructuraImpuesto filtro) throws PortalFiscalizacionException;

}
