package com.femsa.oxxo.portalfiscalizacion.model.exception;

public class PortalFiscalizacionException extends Exception{

    /**
     * Serial de la clase
     */
    private static final long serialVersionUID = -7546510663166279951L;

    /*
     * Codigo de error
     * */
    protected Integer code;

    protected String summary;

    protected Object[] params;

    public PortalFiscalizacionException (Exception claseE){
        super(claseE.getMessage(),claseE.getCause());
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Object[] getParams() {
        return params;
    }

    public void setParams(Object[] params) {
        this.params = params;
    }
}
