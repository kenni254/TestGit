package com.femsa.oxxo.portalfiscalizacion.persistence.base.dao;

import jakarta.persistence.EntityManager;
import com.femsa.oxxo.portalfiscalizacion.model.exception.PortalFiscalizacionException;

import java.util.List;

/*
 * Clase abstract que define los metodos de una dao
 * @author kenni.juarez
 * */
public abstract class AbstractBaseDAO <T> {
    /*
     * Entidad
     * */
    private Class<T> entityClass;

    protected abstract EntityManager getEntityManager();
    /*
     * Constructor de la clase
     * @param entityClass
     * */
    public AbstractBaseDAO(Class<T> entityClass){
        this.entityClass = entityClass;
    }

    /*
     * Metodo insert, realiza commit en el momento
     * @param entity
     * */
    public void create(T entity) throws PortalFiscalizacionException{
        try {
            getEntityManager().merge(entity);
            getEntityManager().flush();
        } catch (Exception e){
            throw new PortalFiscalizacionException( e);
        }
    }

    public void edit (T entity) throws PortalFiscalizacionException {
        try{
            getEntityManager().merge(entity);
            getEntityManager().flush();
        } catch (Exception e){
            throw new PortalFiscalizacionException(e);
        }
    }

    public void remove(T entity) throws PortalFiscalizacionException{
        try{
            getEntityManager().remove(getEntityManager().merge(entity));
            getEntityManager().flush();
        } catch (Exception e) {
            throw new PortalFiscalizacionException(e);
        }
    }

    public T find(Object id){
        return getEntityManager().find(entityClass,id);
    }

    /*
     * Metodo de busqueda por todos
     * */
    @SuppressWarnings("unchecked")
    public List<T> findAll(){
        return getEntityManager().createQuery(
                "select object(o) from " + entityClass.getSimpleName()
                        +" as o").getResultList();
    }

    /*
     * Metodo de busqueda por rango
     * */
    /*
     *
     * */

    /**
     * Metodo contador
     */
    public int count(){
        return ((Long) getEntityManager()
                .createQuery("select count(o) from " + entityClass.getSimpleName()
                        +" as o").getSingleResult()).intValue();
    }

    public void flush(){
        getEntityManager().flush();
    }

}
