package com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="XXSAT_CAT_CATEGORIAS", schema="XXSAT")
@NamedQueries({
        @NamedQuery(name="SatCatCategoriaDo.findAll", query="SELECT c FROM SatCatCategoriaDo c")
})
public class SatCatCategoriaDo implements Serializable {

    /**
     * Serial
     */
    private static final long serialVersionUID = 7441318071757795862L;

    @Id
    @Column(name="CATEGORIA_NO")
    private Long id;

    @Column(name="CATEGORIA")
    private String categoria;

    @Column(name="SUPER_GRUPO_NO")
    private Long superGrupoNo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Long getSuperGrupoNo() {
        return superGrupoNo;
    }

    public void setSuperGrupoNo(Long superGrupoNo) {
        this.superGrupoNo = superGrupoNo;
    }
}
