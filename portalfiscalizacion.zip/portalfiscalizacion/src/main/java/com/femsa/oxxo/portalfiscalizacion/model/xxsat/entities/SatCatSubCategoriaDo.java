package com.femsa.oxxo.portalfiscalizacion.model.xxsat.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name="XXSAT_CAT_SUBCATEGORIAS", schema="XXSAT")
@NamedQueries({
    @NamedQuery(name="SatCatSubCatergoriaDo.findAll", query="SELECT s FROM SatCatSubCategoriaDo s")
})
public class SatCatSubCategoriaDo implements Serializable {
    /**
     * Serial
     */
    private static final long serialVersionUID = 744131807175779562L;

    @Id
    @Column(name="SUB_CATEGORIA_NO")
    private long id;

    @Column(name="SUB_CATEGORIA")
    private String subCategoria;

    @Column(name="CATEGORIA_NO")
    private long categoriaNo;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(String subCategoria) {
        this.subCategoria = subCategoria;
    }

    public long getCategoriaNo() {
        return categoriaNo;
    }

    public void setCategoriaNo(long categoriaNo) {
        this.categoriaNo = categoriaNo;
    }
}
