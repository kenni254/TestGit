package com.femsa.oxxo.portalfiscalizacion.model.xxsat.to;

public class FiltroSatEstructuraImpuesto {
    /*
     * Region
     * */
    private String crRegion;
    /*
     * Tienda
     * */
    private String crTienda;
    /*
     * Estado
     * */
    private String estado;

    public String getCrRegion() {
        return crRegion;
    }

    public void setCrRegion(String crRegion) {
        this.crRegion = crRegion;
    }

    public String getCrTienda() {
        return crTienda;
    }

    public void setCrTienda(String crTienda) {
        this.crTienda = crTienda;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
