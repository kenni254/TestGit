package org.aguzman.webapp.ear.ejb.repositories;

import jakarta.ejb.Local;
import jakarta.security.jacc.PolicyContextException;
import org.aguzman.webapp.ear.ejb.to.FiltroSatEstructuraImpuesto;

import java.util.List;

@Local
public interface ISatEstructuraImpuestoDAO {
    /*
    * Realizar la consulta para obtener las estructuras de
    * impuesto estatal
    * @param filtro
    * */

    List<Object[]> obtenerSatEstructuraImpuesto(
            FiltroSatEstructuraImpuesto filtro) throws PolicyContextException;
}
