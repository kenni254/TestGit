package org.aguzman.webapp.ear.ejb.vo;

/*
* Clase que obtiene los datos que mapean la entidad de estructura de impuesto
* SAT
* */
public class SatEstructuraImpuestoVO {

    private Long id;

    private String superGrupo;

    private String categoria;

    private String subCategoria;

    private String segmento;

    private String ivaVenta;

    private String iepsVenta;

    private String iva0;

    private String excento0;

    private String impuestoEstatal;

    private String vatCode;

    private String crTienda;

    private String crRegion;

    private String estado;

    private String vigenciaInicio;

    private String vigenciaFin;
}
