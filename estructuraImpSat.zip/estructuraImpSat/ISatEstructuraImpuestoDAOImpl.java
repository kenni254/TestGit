package org.aguzman.webapp.ear.ejb.repositories;

public class ISatEstructuraImpuestoDAOImpl implements ISatEstructuraImpuestoDAO{
    /*
    * Indice de la categoria
    * */
    private static final String CATEGORIA = 1;

    /*
    * Nombre del Query
    * */
    private static final String QUERY = ""
}
