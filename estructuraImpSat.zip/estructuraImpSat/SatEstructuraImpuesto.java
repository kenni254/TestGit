package org.aguzman.webapp.ear.ejb.services;

import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import org.aguzman.webapp.ear.ejb.entities.PortalFiscalizacionException;
import org.aguzman.webapp.ear.ejb.to.FiltroSatEstructuraImpuesto;
import org.aguzman.webapp.ear.ejb.vo.SatEstructuraImpuestoVO;

import java.util.List;

@Stateless
public class SatEstructuraImpuesto implements ISatEstructuraImpuesto{

    /*
    * Referencia al Servicio de estructura de impuestos
    * */
    @EJB
    private ISatEstructuraImpuesto estructuraImpuesto;
    @Override
    public List<SatEstructuraImpuestoVO> obtenerEstructurasImpuestos(FiltroSatEstructuraImpuesto filtro) throws PortalFiscalizacionException {
        return estructuraImpuesto.obtenerEstructurasImpuestos(filtro);
    }
}
