package org.aguzman.webapp.ear.ejb.entities;

import jakarta.persistence.*;

@Entity
@Table(name="xxsat_cat_est_impuestos")
@NamedQueries({
        @NamedQuery(name = "SatEstucturaImpuestosDo.findAll", query = "SELECT e FROM SatEstucturaImpuestosDo e")
})
public class SatEstucturaImpuestosDo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="SUPER_GRUPO")
    private String superGrupo;

    @Column(name="CATEGORIA")
    private String categoria;

    @Column(name="SUB_CATEGORIA")
    private String subCategoria;

    @Column(name="SEGMENTO")
    private String segmento;

    @Column(name="IVA_VENTA")
    private String ivaVenta;

    @Column(name="IEPS_VENTA")
    private String iepsVenta;

    @Column(name="IVA_0")
    private String iva0;

    @Column(name = "EXCENTO_0")
    private String excento0;

    @Column(name = "IMPUESTO_ESTATAL")
    private String impuestoEstatal;

    @Column(name = "VAT_CODE")
    private String vatCode;

    @Column(name = "CR_TIENDA")
    private String crTienda;

    @Column(name = "CR_REGION")
    private String crRegion;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "VIGENCIA_INICIO")
    private String vigenciaInicio;

    @Column(name = "VIGENCIA_FIN")
    private String vigenciaFin;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSuperGrupo() {
        return superGrupo;
    }

    public void setSuperGrupo(String superGrupo) {
        this.superGrupo = superGrupo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(String subCategoria) {
        this.subCategoria = subCategoria;
    }

    public String getSegmento() {
        return segmento;
    }

    public void setSegmento(String segmento) {
        this.segmento = segmento;
    }

    public String getIvaVenta() {
        return ivaVenta;
    }

    public void setIvaVenta(String ivaVenta) {
        this.ivaVenta = ivaVenta;
    }

    public String getIepsVenta() {
        return iepsVenta;
    }

    public void setIepsVenta(String iepsVenta) {
        this.iepsVenta = iepsVenta;
    }

    public String getIva0() {
        return iva0;
    }

    public void setIva0(String iva0) {
        this.iva0 = iva0;
    }

    public String getExcento0() {
        return excento0;
    }

    public void setExcento0(String excento0) {
        this.excento0 = excento0;
    }

    public String getImpuestoEstatal() {
        return impuestoEstatal;
    }

    public void setImpuestoEstatal(String impuestoEstatal) {
        this.impuestoEstatal = impuestoEstatal;
    }

    public String getVatCode() {
        return vatCode;
    }

    public void setVatCode(String vatCode) {
        this.vatCode = vatCode;
    }

    public String getCrTienda() {
        return crTienda;
    }

    public void setCrTienda(String crTienda) {
        this.crTienda = crTienda;
    }

    public String getCrRegion() {
        return crRegion;
    }

    public void setCrRegion(String crRegion) {
        this.crRegion = crRegion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getVigenciaInicio() {
        return vigenciaInicio;
    }

    public void setVigenciaInicio(String vigenciaInicio) {
        this.vigenciaInicio = vigenciaInicio;
    }

    public String getVigenciaFin() {
        return vigenciaFin;
    }

    public void setVigenciaFin(String vigenciaFin) {
        this.vigenciaFin = vigenciaFin;
    }
}
