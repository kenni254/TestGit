package org.aguzman.webapp.ear.ejb.services;

import jakarta.ejb.Local;
import org.aguzman.webapp.ear.ejb.entities.PortalFiscalizacionException;
import org.aguzman.webapp.ear.ejb.to.FiltroSatEstructuraImpuesto;
import org.aguzman.webapp.ear.ejb.vo.SatEstructuraImpuestoVO;

import java.util.List;

/*
* Integrador para obtener la estructura de impuestos
* */
@Local
public interface ISatEstructuraImpuesto {
    /*
    * Se comunica con el servicio para obtener los registros de las estructuras
    * de impuestos
    *
    * */
    List<SatEstructuraImpuestoVO> obtenerEstructurasImpuestos(FiltroSatEstructuraImpuesto filtro)
        throws PortalFiscalizacionException;

}
